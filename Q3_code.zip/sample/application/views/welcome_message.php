<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  /*background-color: black;*/
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password],input[type=time],input[type=number] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
select{
	width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>

<form action="<?php echo base_url();  ?>Welcome/addinformation" method="post">
     <h1>  Informantion</h1>
     <?php
            if($this->session->flashdata('success')){ ?>
            	 <span style="color: green;">  <h3>
                     <?php echo $this->session->flashdata('success') ?>
                      </h3>     </span>  
                  
              

        <?php }else if($this->session->flashdata('message')){ ?>
            <span style="color: red;">  <h3>          
            <?php echo $this->session->flashdata('message') ?>       </h3>     </span>
        <?php }  ?> 
     <hr>

    <label for="email"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" id="name" required>


 <label for="email"><b>Mobile</b></label>
    <input type="number" placeholder="Enter Mobile" name="number" id="number" required>
 
 <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" id="email" required>

 
 <label><b>Gender</b></label>
  <select name="gender" id="cars">
  <option value="male">Male</option>
  <option value="female">Female</option>
 
</select>
 <label for="email"><b>Address</b></label>
    <input type="text" placeholder="Enter Address" name="address" id="address" required>

    <label for="psw"><b>Fees</b></label>
    <input type="text" placeholder="Enter Fees" name="fees" id="fees" required>

    <label for="psw-repeat"><b>Preferable Time</b></label>
    <input type="time" placeholder="Repeat Password" name="preferable_time" id="preferable_time" required>
    <hr>
 
    <button type="submit" class="registerbtn">Register</button>
  </div>
  
  
</form>


<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
 
<h2><center>information Table</center></h2>

<table>
  <tr>
  	 <th>Sr</th>
    <th>Name</th>
    <th>Mobile </th>
    <th>Email </th>
    <th>Gender </th>
    <th>Address </th>
    <th>Fees</th>
    <th>Preferable Time </th>
 
  </tr>
 
<?php $i = 1; 
  
      foreach($student_info as $row):  ?>

  <tr>
    <td><?php  echo $i;  ?></td>
     <td><?php  echo   $row->name; ?></td>
     <td><?php  echo   $row->number; ?></td>
     <td><?php  echo   $row->email; ?></td>
     <td><?php  echo   $row->gender; ?></td>
     <td><?php  echo   $row->address; ?></td>
     <td><?php  echo   $row->fees; ?></td>
     <td><?php  echo $newDateTime = date('h:i A', strtotime($row->preferable_time));   ?></td>
     
  </tr>
 <?php  $i++;endforeach; ?>  
</table>


</body>
</html>
