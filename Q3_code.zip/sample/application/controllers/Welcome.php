 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

function __construct(){

    parent::__construct();
 
        date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
 
        $this->load->model('CommonModel');
     
       
     
    }
   public function index()
{  
 $whereCond = array('status'=>"1",);
       $data['student_info'] = $this->CommonModel->selectAllDataWhereCondOrderBy("*","student_ino",$whereCond,"id");
       $this->load->view('welcome_message',$data);
}




function addinformation()
{  
$data=array();

    $this->form_validation->set_rules('name', 'Name', 'required');
    $this->form_validation->set_rules('number', 'Number', 'required');
    $this->form_validation->set_rules('email', 'Email', 'required');
    $this->form_validation->set_rules('address', 'Address', 'required');
    $this->form_validation->set_rules('fees', 'fees', 'required');
    $this->form_validation->set_rules('preferable_time', 'Preferable Time', 'required');
    if($this->form_validation->run() == true){
   

    $data['name']=$this->input->post('name');
$data['number']=$this->input->post('number');
$data['email']=$this->input->post('email');
    $data['gender']=$this->input->post('gender');
$data['address']=$this->input->post('address');
    $data['fees']=$this->input->post('fees');
$data['preferable_time']=$this->input->post('preferable_time');
$data['date']=date('y/d/m');
// echo "<pre>";
 //  print_r($data);
 //  die;
  $result21=$this->CommonModel->insertData("student_ino", $data);
       if($result21 == true){
        $this->session->set_flashdata('message',"Student Information Added Succesfully..!");
  $whereCond = array('status'=>"1",);
       $data['student_info'] = $this->CommonModel->selectAllDataWhereCondOrderBy("*","student_ino",$whereCond,"id");
       $this->load->view('welcome_message',$data);
       }
       else{
        $this->session->set_flashdata('message',"Some Problem While Adding Information");
  $whereCond = array('status'=>"1",);
       $data['student_info'] = $this->CommonModel->selectAllDataWhereCondOrderBy("*","student_ino",$whereCond,"id");
       $this->load->view('welcome_message',$data);

       }

    }
    else{
            //Form validation Else 1
            $this->session->set_flashdata('message',"Enter Valid Information");
  $whereCond = array('status'=>"1",);
       $data['student_info'] = $this->CommonModel->selectAllDataWhereCondOrderBy("*","student_ino",$whereCond,"id");
       $this->load->view('welcome_message',$data);

        }



}












}