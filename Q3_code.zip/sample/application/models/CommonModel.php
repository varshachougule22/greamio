<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CommonModel extends CI_Model{ 


function insertData($table,$data)
    {

        $this->db->insert($table, $data);

        $lastId = $this->db->insert_id();

        return $lastId;
    }



function selectAllDataWhereCondOrderBy($select,$table,$whereCond,$orderCol)
    {

        $this->db->select($select);
        $this->db->from($table);
        $this->db->where($whereCond);
        $this->db->order_by($orderCol, "ASC");
        $result = $this->db->get()->result();

        return $result;
     } 






















    

}